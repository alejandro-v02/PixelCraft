function Reports(){
    return(
        <div>
            <h2>Reportes</h2>
        </div>
    )
}

export default Reports;